﻿
using Microsoft.AspNetCore.Mvc;
using Models;
using SportClubProject.Repository;


namespace SportClubProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {

        //userrepository impl
        private readonly IUserRepository userRepository;

       //loggers
       private readonly ILogger<UserController> _logger;
        
        
        //injecting user repository impl
        public UserController(IUserRepository userRepository, ILogger<UserController> logger)
        {
            _logger = logger;
            this.userRepository = userRepository;
        }



        
        
        //getting sports from repository
        [HttpGet("getallsports")]
        public ActionResult<IEnumerable<Sports>> GetAllSports() 
        
        {
           _logger.LogInformation("starts getting all sports");
           return userRepository.GetAllSports().ToList();
        }
      

        
        
        
        //getting all booking details from repository
        [HttpGet("getallbookingdetais")]
        public ActionResult<IEnumerable<BookingDetails>> GetAllBookingDetails()
        {
            return userRepository.GetAllBookingDetails().ToList();
        }

       
        
        
        
        
        //getting all coupons from repository
        [HttpGet("getallcoupons")]
        public ActionResult<IEnumerable<Coupons>> GetAllCoupons()
        {
            return userRepository.GetAllCoupons().ToList(); 
        }

       
        
        
                             
        
        //getting all courts from repository
        [HttpGet("getallcourts")]
        public List<string> GetAllCourts(string SportName,string Date)
        {
            return userRepository.GetAllCourts(SportName, Date).ToList();
        }






        //getting all slots from repository
        [HttpGet("getallslots")]
        public List<string> GetAllSlots(string SportName,string Date,string CourtName)
        {
            return userRepository.GetAllSlots(SportName,Date,CourtName).ToList();
        }



        //validating mobile
        [HttpGet("verifymobile")]
        public bool VerifyMobile(long MobileNumber)
        {
            return userRepository.ValidateMobileNumber(MobileNumber);
        }
    }
}
