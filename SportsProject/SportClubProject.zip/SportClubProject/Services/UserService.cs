﻿using SportClubProject.Repository;

namespace SportClubProject.Services
{
    public class UserService
    {

        private SportsDbContext sportsDbContext;

        public UserService()
        {
        }

        public UserService(SportsDbContext sportsDbContext)
        {
            this.sportsDbContext = sportsDbContext;
        }



        //getting courts from sports dbcontext
        public List<string> GetCourts(string sportname, string date)
        {

            List<string> totalcourts = new List<string>();
            List<string> resultcourts = new List<string>();
            var res = sportsDbContext.Sports.Where(e => e.SportName.Equals(sportname)).Select(e => e.Courts).ToList();
            foreach (var coupon in res)
            {
                foreach (var val in coupon)
                {
                    totalcourts.Add(val.CourtsName);
                }
            }
            List<string> courtlist = sportsDbContext.BookingDetails.Where(e => e.SportName.Equals(sportname) && e.Bookingdate.Equals(date)).Select(e => e.CourtName).ToList();
            if (courtlist.Count == 0)
            {

                return totalcourts;
            }
            else
            {

                foreach (string court in totalcourts)
                {
                    int count = 0;
                    foreach (string cout in courtlist)
                    {
                        if (cout.Equals(court))
                        {
                            count++;
                        }
                    }
                    if (count < 4)
                    {
                        resultcourts.Add(court);
                    }
                }

            }
            return resultcourts;

        }



        //get all slots from db context

        public List<string> GetSlots(string sportname, string date, string courtname)
        {
            List<string> totalslots = sportsDbContext.Slots.Select(e => e.SlotTime).ToList();
            List<string> bookedslots = sportsDbContext.BookingDetails.Where(e => e.SportName.Equals(sportname) && e.Bookingdate.Equals(date)
                                       && e.CourtName.Equals(courtname)).Select(e => e.SlotTime).ToList();
            foreach (string slot in bookedslots)
            {
                if (totalslots.Contains(slot))
                {
                    totalslots.Remove(slot);
                }
            }
            return totalslots;
        }



        //checking mobile number present or not
        public bool ValidateMobileNumber(long mobileNumber)
        {

            bool isMobileNumberExist= sportsDbContext.UserDetails.Any(user => user.UserMobile == mobileNumber);
            return isMobileNumberExist;
        }
    }
}
