﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models;
using SportClubProject.AdminRepository;


namespace SportClubProject.AdminController
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourtsController : ControllerBase
    {




        //sport repository
        private readonly ICourtsRepository courtsRepository;

        public CourtsController(ICourtsRepository courtsRepository)
        {
            this.courtsRepository = courtsRepository;
        }




        //get all sports
        [HttpGet("getallcourts")]
        public IEnumerable<Courts> GetAllCourts()
        {
            IEnumerable<Courts> courts= courtsRepository.GetAllCourts().ToList();
            return courts;
        }


        //save sport
        [HttpPost("savecourt")]
        public Courts SaveCourt(Courts court)
        {
            Courts courts = courtsRepository.SaveCourt(court);
            return courts;
        }

        //delete sport
        [HttpDelete("deletecourt")]
        public Courts DeleteCourt(int id)
        {
            Courts court = courtsRepository.DeleteCourt(id);
            return court;
        }


        //update sport
        [HttpPut("updatecourt")]
        public Courts UpdateCourt(Courts court,int id)
        {
            Courts courts=courtsRepository.UpdateCourt(court,id);
            return courts;

        }

        }

    }


