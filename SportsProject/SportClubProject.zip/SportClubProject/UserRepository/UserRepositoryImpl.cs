﻿

using Microsoft.EntityFrameworkCore;
using Models;
using SportClubProject.Services;

namespace SportClubProject.Repository
{
    public class UserRepositoryImpl : IUserRepository

    {

        //sports dbcontext
        public readonly SportsDbContext sportsDbContext;

        //user service

        public readonly UserService userService;

        

        // Constructor injection with both dependencies
        public UserRepositoryImpl(UserService userService, SportsDbContext sportsDbContext)
        {
            this.userService = userService;
            this.sportsDbContext = sportsDbContext;
        }

        //get sports 
        public IEnumerable<Sports> GetAllSports()
        {
            return sportsDbContext.Sports.Include(e => e.Courts).ToList();
        }

        //get all Booking details
        public IEnumerable<BookingDetails> GetAllBookingDetails()
        {
            return sportsDbContext.BookingDetails.ToList();
        }


        //getting all coupons
        public IEnumerable<Coupons> GetAllCoupons()
        {
            return sportsDbContext.Coupons.ToList();
        }


        //getting all courts
        public List<string> GetAllCourts(string SportName,string date)
        {
            return userService.GetCourts(SportName, date);
        }


        //getting all slots
        public List<string> GetAllSlots(string SportName,string date, string CourtName)
        {
            return userService.GetSlots(SportName, date, CourtName);
            
        }


        //checking mobile number is present or not
        public bool ValidateMobileNumber(long mobileNumber)
        {
            return userService.ValidateMobileNumber(mobileNumber);
        }



    }
}
