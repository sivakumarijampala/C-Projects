﻿


using Models;

namespace SportClubProject.Repository
{
    public interface IUserRepository
    {

        public IEnumerable<Sports> GetAllSports();
        public IEnumerable<BookingDetails> GetAllBookingDetails();
        public IEnumerable<Coupons> GetAllCoupons();
        public List<string> GetAllCourts(string SportName,string date);
        public List<string> GetAllSlots(string SportName,string date,string CourtName);


        public bool ValidateMobileNumber(long MobileNumber);
    }
}
