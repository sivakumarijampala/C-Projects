using Microsoft.EntityFrameworkCore;
using SportClubProject.AdminRepository;
using SportClubProject.Repository;
using SportClubProject.Services;
using SportsProject.Services;
using Twilio.Clients;

var builder = WebApplication.CreateBuilder(args);


// Add services to the container.
builder.Services.AddDbContext<SportsDbContext>(options =>
   options.UseSqlServer(builder.Configuration.GetConnectionString("SportsDbConnection")));



//adding services to dependancy injection container
builder.Services.AddScoped<UserService, UserService>();


//add repository to dependany injection container
builder.Services.AddScoped
    <IUserRepository,UserRepositoryImpl>();


//adding sports repository 
builder.Services.AddScoped<ISportsRepository,SportRepositoryImpl>();

builder.Services.AddScoped<ICourtsRepository ,CourtsRepositoryImpl>();       

//adding slots repository
builder.Services.AddScoped<ISlotsRepository,SlotsRepositoryImpl>();


//twilio service
builder.Services.AddSingleton<TwilioService>();

builder.Services.AddHttpClient<ITwilioRestClient, Twiloclient>();

//cross origin policy

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowOrigin",
        builder =>
        {
            builder.AllowAnyOrigin()
                   .AllowAnyMethod()
                   .AllowAnyHeader();
        });
});



builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();
app.UseCors("AllowOrigin");

app.MapControllers();

app.Run();
