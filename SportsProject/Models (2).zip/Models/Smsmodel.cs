﻿namespace SportsProject.Controllers
{
    public class Smsmodel
    {
        public string To { get; set; }
        public string From { get; set; }
        public string Message { get; set; }
    }
}
